(function($) {
 
 $(document).ready(function(){
   $('.slick-home').slick();
});


})(jQuery);



