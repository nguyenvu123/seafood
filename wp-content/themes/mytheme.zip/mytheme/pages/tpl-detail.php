<?php 

echo 1111;
echo "string";
 ?>