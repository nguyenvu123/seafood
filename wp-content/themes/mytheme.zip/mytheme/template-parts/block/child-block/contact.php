<div class="section-contact">
	<p class="title">ENJOY OUR CUISINE! </p>
	<div class="row">
		<div class="col-3">
			<img src="<?php echo THEME_DIR.'/source/images/phone.jpg' ?>">
			<p>call us</p>
		</div>
		<div class="col-3">
			<img src="<?php echo THEME_DIR.'/source/images/datcho.jpg' ?>">
			<p>call us</p>
		</div>
		<div class="col-3">
			<img src="<?php echo THEME_DIR.'/source/images/monan.jpg' ?>">
			<p>call us</p>
		</div>
	</div>
</div>