<div class="second-block">
	<p class="title-main">OTHERS RISOTTOS FOR YOU!</p>
	<div class="row">
		<div class="col-5">
			<p>Following the new opening of</p>
			<p>"Risotteria Melotti Roma":</p>
			<p>RISOTTO CACIO E PEPE</p>
			<div class="include-img">
				<img src="<?php echo THEME_DIR.'/source/images/items2.jpg' ?>">
				<p class="name">Risotto with Cacio cheese and pepper</p>
			</div>
		</div>
		<div class="col-5">
			<p>Following the new opening of</p>
			<p>"Risotteria Melotti Roma":</p>
			<p>RISOTTO CACIO E PEPE</p>
			<div class="include-img">
				<img src="<?php echo THEME_DIR.'/source/images/items2.jpg' ?>">
				<p class="name">Risotto with Cacio cheese and pepper</p>
			</div>
		</div>
	</div>
</div>