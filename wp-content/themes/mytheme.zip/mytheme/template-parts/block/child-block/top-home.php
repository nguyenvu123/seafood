<div class="traditional">
	<div class="title">
		<p>The authentic Italian RISOTTO</p>
	</div>
	<div class="include-items">
		<p class="subtitle">RISOTTO and TRADITIONAL ITALIAN CUISINE - 100% Gluten Free</p>
		<div class="items">
			<div class="row">
				<div class="col-4">
					<img src="<?php echo THEME_DIR.'/source/images/items1.jpg' ?>">
					<p>mushrooms Risotto</p>
				</div>
				<div class="col-4">
					<img src="<?php echo THEME_DIR.'/source/images/items1.jpg' ?>">
					<p>mushrooms Risotto</p>
				</div>
				<div class="col-4">
					<img src="<?php echo THEME_DIR.'/source/images/items1.jpg' ?>">
					<p>mushrooms Risotto</p> 
				</div>
			</div>
		</div>
	</div>
</div>