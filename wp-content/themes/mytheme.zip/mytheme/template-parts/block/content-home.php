<section id="home-content">
	<div class="container">
		<?php  get_template_part('template-parts/block/child-block/top-home'); ?>
		<?php  get_template_part('template-parts/block/child-block/second-home'); ?>
		<?php  get_template_part('template-parts/block/child-block/contact'); ?>
	</div>
</section>