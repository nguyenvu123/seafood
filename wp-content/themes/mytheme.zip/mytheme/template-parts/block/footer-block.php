<div class="section-footer">
	<div class="row">
		<div class="col-3">
			<p class="title">Follow us!</p>
			<p class="sub-title">STAY IN CONTACT WITH US,</br>AND SHARE OUR PASSION</p>
			<div class="icon">
				
			</div>
			<div>
				<a href="">Newsletter</a>
			</div>
		</div>
		<div class="Time col-3">
			<p class="title">Opening Times</p>
			<p class="hour">Monday - Friday</p>
				<p>12:00 PM - 10:30 PM</p>
			<div class="sd-sa-day">
				<p>Saturday - Sunday</p>
				<p>11:30 AM - 11:30 PM</p>
				<p class="phone">Phone: +016467558939</p>
			</div>
		</div>
		<div class="col-3">
			<div class="map">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2742.460715263369!2d109.24618874782378!3d13.57081792401791!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x42286d4b0234bc2d!2sNh%C6%B0+Hoa+seafood!5e0!3m2!1sen!2s!4v1523535748069" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
			</div>
		</div>
	</div>
</div>