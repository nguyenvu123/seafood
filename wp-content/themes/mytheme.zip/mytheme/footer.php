
<footer id="footer" role="contentinfo">
	<div class="container">
		<?php  get_template_part('template-parts/block/footer-block'); ?>
	</div>
</footer>
 <?php wp_footer(); ?> 
</body>
</html>